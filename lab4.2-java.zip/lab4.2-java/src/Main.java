import java.util.List;

public class Main {
    public static void main(String[] args) {
        MobileCompany company = new MobileCompany();

        // Додавання тарифів до компанії
        company.addTariff(new PrepaidTariff("Prepaid 1", 10.0, 100));
        company.addTariff(new PostpaidTariff("Postpaid 1", 20.0, 200));

        // Підрахунок та виведення загальної кількості клієнтів
        int totalCustomers = company.getTotalCustomers();
        System.out.println("Загальна кількість абонентів: " + totalCustomers);

        // Сортування тарифів за абонентською платою
        company.sortTariffsBySubscriptionFee();

        // Знайдені тарифи у заданому діапазоні параметрів
        double minFee = 15.0;
        double maxFee = 25.0;
        List<Tariff> matchingTariffs = company.findTariffsInRange(minFee, maxFee);
        System.out.println("Тарифи в діапазоні:" + minFee + " - " + maxFee + ": " + matchingTariffs);
    }
}
