import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class MobileCompany {
    private List<Tariff> tariffs;

    public MobileCompany() {
        tariffs = new ArrayList<>();
    }

    public void addTariff(Tariff tariff) {
        tariffs.add(tariff);
    }

    public int getTotalCustomers() {
        int totalCustomers = 0;
        for (Tariff tariff : tariffs) {
            // Логіка для підрахунку клієнтів для кожного тарифу
        }
        return totalCustomers;
    }

    public void sortTariffsBySubscriptionFee() {
        Collections.sort(tariffs, (t1, t2) -> Double.compare(t1.getSubscriptionFee(), t2.getSubscriptionFee()));
    }

    public List<Tariff> findTariffsInRange(double minFee, double maxFee) {
        List<Tariff> matchingTariffs = new ArrayList<>();
        for (Tariff tariff : tariffs) {
            double fee = tariff.getSubscriptionFee();
            if (fee >= minFee && fee <= maxFee) {
                matchingTariffs.add(tariff);
            }
        }
        return matchingTariffs;
    }
}
