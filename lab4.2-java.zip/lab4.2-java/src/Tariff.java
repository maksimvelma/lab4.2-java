// Базовий клас для тарифів
class Tariff {
    private String name;
    private double subscriptionFee;

    public Tariff(String name, double subscriptionFee) {
        this.name = name;
        this.subscriptionFee = subscriptionFee;
    }

    public double getSubscriptionFee() {
        return subscriptionFee;
    }
}

// Попередньо оплачуваний тариф успадковується від Tariff
class PrepaidTariff extends Tariff {
    private int prepaidBalance;

    public PrepaidTariff(String name, double subscriptionFee, int prepaidBalance) {
        super(name, subscriptionFee);
        this.prepaidBalance = prepaidBalance;
    }
}

// Тариф постоплати також успадковується від Tariff
class PostpaidTariff extends Tariff {
    private int creditLimit;

    public PostpaidTariff(String name, double subscriptionFee, int creditLimit) {
        super(name, subscriptionFee);
        this.creditLimit = creditLimit;
    }
}
